import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs';
import { OktaAuthService } from '@okta/okta-angular';
import { UserService } from 'src/lib/service/user.service';

@Injectable({
  providedIn: 'root'
})

export class LoginAuthGuard implements CanActivate {

  constructor(
    public oktaAuth: OktaAuthService, public userService: UserService, public router: Router
  ) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      return new Promise(async (resolve)=>{
        const session = await this.userService.getSession();
        if ((session && !session.id)|| !session) {
          window.location.href="https://stryker-build64.adobecqms.net/us/en/poc-us-index.html"
        }
      resolve(false);
    })
    
  }
}