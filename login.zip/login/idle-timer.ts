class IdleTimer {
    eventHandler: any;
    timeout: any;
    onTimeout: any;
    onRenewSession: any;
    interval: any;
    timeoutTracker: any;
    expiresAt: number;
    isUserActive: boolean;
    constructor({ timeout, onTimeout, expiresAt, onRenewSession }) {
        this.timeout = timeout;
        this.onTimeout = onTimeout;
        this.expiresAt = expiresAt - (1000 * 60);
        this.onRenewSession = onRenewSession;
        this.eventHandler = this.updateExpiredTime.bind(this);
        this.tracker();
        this.startInterval();
    }

    renewSession() {
        this.cleanUp();
        this.onRenewSession();
    }

    startInterval() {
        this.updateExpiredTime(false);
        this.interval = setInterval(() => {
            const expiredTime = parseInt(localStorage.getItem("_expiredTime"), 10);
            const now = new Date().getTime();

            if (expiredTime < Date.now()) {
                this.isUserActive = false;
                if (this.onTimeout) {
                    this.onTimeout();
                    this.cleanUp();
                }
            }
            else if (this.expiresAt < now && this.isUserActive) {
                this.renewSession();
            }
        }, 1000);
    }

    updateExpiredTime(isUserActive) {
        if (this.timeoutTracker) {
            clearTimeout(this.timeoutTracker);
        }
        this.timeoutTracker = setTimeout(() => {
            this.isUserActive = isUserActive;
            localStorage.setItem("_expiredTime", String(Date.now() + this.timeout * 1000));
        }, 300);
    }

    tracker() {
        // window.addEventListener("mousemove", () => { this.eventHandler(true) });
        window.addEventListener("scroll", () => { this.eventHandler(true) });
        window.addEventListener("keydown", () => { this.eventHandler(true) });
    }

    cleanUp() {
        this.isUserActive = false;
        clearInterval(this.interval);
        // window.removeEventListener("mousemove", () => { this.eventHandler(false) });
        window.removeEventListener("scroll", () => { this.eventHandler(false) });
        window.removeEventListener("keydown", () => { this.eventHandler(false) });
    }
}
export default IdleTimer;
