import { ChangeDetectorRef, Component, NgZone, OnInit } from '@angular/core';
import { Router, NavigationStart, Route, ActivatedRoute } from '@angular/router';
import { MatDialog } from "@angular/material/dialog";
import { RequestAccessDialogComponent } from "./request-access-dialog/request-access-dialog.component";

import { OktaAuthService } from '@okta/okta-angular';
//import { Tokens } from '@okta/okta-auth-js';
import * as OktaSignIn from '@okta/okta-signin-widget';
import CiamConfig from '../app.config';
import * as login from './login.json';
import * as loginfr from './login-FR.json';
import * as loginjp from './login-JP.json';
const DEFAULT_ORIGINAL_URI = window.location.origin;
import { ContactUsService } from '../contact-us.service';
import { UserService } from 'src/lib/service/user.service';
import { LoginStatusWidgetService } from '../login-status-widget.service';
import { User } from 'IUser';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { WindowDigitalDataService } from '../services/windowDigitalData.service';
import { TranslateService } from '@ngx-translate/core';

export interface ContactUs {
  primaryEmail: '';
  primaryPhoneNumber: '';
  primaryAddress: '';
  secondaryEmail: '';
  secondaryPhoneNumber: '';
  secondaryAddress: '';
}

let clientId = CiamConfig.oidc[window.location.origin].application_context_id;

@Component({
  selector: 'app-secure',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  public contactUsData: any = login;
  contactus: ContactUs = ({} as any) as ContactUs;
  admin: boolean;
  public loginData: any = login;
  public loginfr: any = loginfr;
  public loginjp: any = loginjp;
  widget: any;
  contactusValue: any = {};
  authService;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAccessDenied: boolean;
  emailValue: any;
  redirectUrl: any;
  title: any;
  errorMsg: any;
  persona: string = '';
  internalCheck:any;

  translation: string = '';

  
    user:User;

    guid:any;

  constructor(
    public oktaAuth: OktaAuthService,
    private router: Router,
    private contactUsService: ContactUsService,
    private userService: UserService,
    private loginStatusWidgetService: LoginStatusWidgetService,
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private changeDetectorRef: ChangeDetectorRef,
    public http: HttpClient,
    public digitalDtatService : WindowDigitalDataService,
    public translator: TranslateService,
    private zone: NgZone
  ) {
    
    this.admin = false;
    this.authService = oktaAuth;
    this.isLoading = false;
    this.isAccessDenied = false;
    this.route.queryParams
      .subscribe(params => {
        this.redirectUrl = params.redirectURL;

        if(params.appContext){
          clientId = params.appContext
        }
        this.http.get(`${environment.getExistingAppMetaData}/${clientId}`).subscribe((res) => {
          // @ts-ignore
          const appMetadata = res ? res[0] ? res[0] : {} : {};
          if (appMetadata.rulesForNonHCPs == 'Open') {
            this.persona = this.loginData.login.persona;
          }
  
          if (appMetadata.rulesForNonHCPs == 'Restricted') {
            this.persona = this.loginData.login[appMetadata.targetAudience];
          }
        });
      }
    );
    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        switch (event.url) {
          case '/login':
            break;
          default:
            this.widget && this.widget.remove();
            break;
        }
      }
    });
  }
  login() {
    this.oktaAuth.signInWithRedirect({
      originalUri: '/main',
    });
  }

  async ngOnInit() {
    this.digitalDtatService.setDigitalData(window.location.href, "login page", "", false, clientId, window.location.pathname);
    this.isLoading = true;
    this.isAccessDenied = false;
    this.dataBind();
    this.contactDetails();
    this.redirectIfAlreadyLoggedin();
    this.oktaAuth.setOriginalUri('/main');
    this.widget.on('afterError', (context, error) => {
      // reset-password
      // AuthApiError
      this.errorMsg = error?.xhr?.responseJSON?.errorSummary ?? '';
      // The password does not meet the complexity requirements
      // of the current password policy.
      // 403
      if (error.message == 'User is not assigned to the client application.') {
        this.zone.run(() => {
          this.dialog.open(RequestAccessDialogComponent, {
            panelClass: 'requestAccess-dialog-container',
          hasBackdrop: true,
          disableClose: true,
          data: {
            email: this.emailValue
          },
          minWidth: '50vw',
      
        });
      })
      }
      this.changeDetectorRef.detectChanges();
    });
    
    this.widget.on('afterRender', (context) => {
      // this.changeDetectorRef.detectChanges();
    });

      this.userService.oktaUesr$.subscribe((userClaims) => {
        if (userClaims) {
        this.user = userClaims;
        this.guid = userClaims.GUID;
        this.digitalDtatService.updateDigitaldataformSubmitted(false);
        }
        }, (error) => {
        
        })
       
  }

  //get email value on next and submit button click
  getEmail(evt) {
    const target = evt.target
    if (target.id == "idp-discovery-submit" || target.id == 'okta-signin-submit') {
      let inputValue = target.form[0].value;
      if (inputValue !== '')
      localStorage.setItem('emailValue', inputValue);
    }
  }

  async redirectIfAlreadyLoggedin() {
    this.isAuthenticated = await this.oktaAuth.isAuthenticated();
    if (this.isAuthenticated) {
      this.router.navigateByUrl('/main');
    }
  }
  contactDetails() {
    this.contactUsService.getContactUs(this.guid).subscribe((response) => {
      this.contactusValue = response.data;
      for (const property in this.contactusValue) {
        if (!this.contactusValue[property]) {
          this.contactusValue[property] = '';
        }
      }
    });
  }
  dataBind() {

    




    this.widget = new OktaSignIn({
      baseUrl: CiamConfig.oidc[window.location.origin].issuer.split(
        '/oauth2'
      )[0],
      scopes: CiamConfig.oidc[window.location.origin].scopes,
      authParams: {
        pkce: true,
      },
      features: {
        idpDiscovery: true,
        registration: true, // REQUIRED
      },
      idpDiscovery: {
        requestContext: window.location.href,
      },
      
      i18n: {
        en: {
          'errors.E0000004' : this.translator.instant('login.wrong_password'),
          'primaryauth.title': this.translator.instant('login.title'),
          'primaryauth.submit': this.translator.instant('login.submit'),
          'primaryauth.username.placeholder': this.translator.instant('login.email'),
          'registration.signup.text': this.translator.instant('login.register'),
          'oform.errorbanner.title': this.translator.instant('login.errorbanner_title'),
          'model.validation.field.blank': this.translator.instant('login.emailfield_required'),
          'error.password.required': this.translator.instant('login.passwordfield_required'),
          'errors.E0000006': this.translator.instant('login.reset_password_error'),
          'password.forgot.email.or.username.placeholder': this.translator.instant('login.forgot_password.email_field_label'),
          'password.forgot.email.or.username.tooltip':  this.translator.instant('login.forgot_password.email_field_label'),
          'password.forgot.emailSent.title': this.translator.instant('login.email_sent'),
          'model.validation.field.invalid.format.email': this.translator.instant('login.invalid_email_address'),
          'error.auth.lockedOut':this.translator.instant('login.wrong_password'),
          'signout':this.translator.instant('login.backto_signin'),
          'password.reset':this.translator.instant('login.resetpassword'),
          'mfa.challenge.enterCode.placeholder':this.translator.instant('login.enter_code'),
          'factor.totpSoft.oktaVerify':this.translator.instant('login.mfa_verify'),
        },
        fr: {
          'errors.E0000004' : this.loginfr.login.wrong_password,
          'primaryauth.title': this.loginfr.login.title,
          'primaryauth.submit': this.loginfr.login.submit,
          'primaryauth.username.placeholder': this.loginfr.login.email,
          'registration.signup.text':this.loginfr.login.register,
          'oform.errorbanner.title': this.loginfr.login.errorbanner_title,
          'model.validation.field.blank': this.loginfr.login.emailfield_required,
          'error.password.required': this.loginfr.login.passwordfield_required,
          'errors.E0000006': this.loginfr.login.reset_password_error,
          'password.forgot.email.or.username.placeholder': this.loginfr.forgot_password.email_field_label,
          'password.forgot.email.or.username.tooltip':  this.loginfr.forgot_password.email_field_label,
          'password.forgot.emailSent.title': this.loginfr.login.email_sent,
          'model.validation.field.invalid.format.email': this.loginfr.login.invalid_email_address,
          'error.auth.lockedOut':this.loginfr.login.wrong_password,
        },
        ja: {
          'errors.E0000004' : this.loginjp.login.wrong_password,
          'primaryauth.title': this.loginjp.login.title,
          'primaryauth.submit': this.loginjp.login.submit,
          'primaryauth.username.placeholder': this.loginjp.login.email,
          'registration.signup.text':this.loginjp.login.register,
          'oform.errorbanner.title': this.loginjp.login.errorbanner_title,
          'model.validation.field.blank': this.loginjp.login.emailfield_required,
          'error.password.required': this.loginjp.login.passwordfield_required,
          'errors.E0000006': this.loginjp.login.reset_password_error,
          'password.forgot.email.or.username.placeholder': this.loginjp.forgot_password.email_field_label,
          'password.forgot.email.or.username.tooltip':  this.loginjp.forgot_password.email_field_label,
          'password.forgot.emailSent.title': this.loginjp.login.email_sent,
          'model.validation.field.invalid.format.email': this.loginjp.login.invalid_email_address,
          'error.auth.lockedOut':this.loginjp.login.wrong_password,
        },
      },
      registration: {
        click: () => {
          this.zone.run(() => {
              this.router.navigate(['/email']);
          });    
        },
      },
      processCreds: (creds) => {
        this.emailValue = creds.username;
        // localStorage.setItem('emailValue', creds.username);

        },
      clientId: CiamConfig.oidc[window.location.origin].clientId,
      redirectUri: CiamConfig.oidc[window.location.origin].redirectUri,
      postLogoutRedirectUri:
        CiamConfig.oidc[window.location.origin].post_logout_redirect_uri,
    });

    this.widget.authClient.session.exists().then(async (sessionExists) => {
      
     
      if (sessionExists) {
        
        this.widget.authClient.token
          .getWithoutPrompt({
            responseType: 'id_token',
            // or array of types sessionToken: 'testSessionToken'
            // optional if the user has an existing Okta session
          })
          .then(async (res) => {

            var tokens = res.tokens;

            const emailId = localStorage.getItem('emailValue');
            var domainValue = emailId.split('@');
            if(environment.aemLoginPage !== ''){
              if(domainValue[1] == "stryker.com"){
               window.location.href = environment.aemLoginPage;
              }
            }
           else{
            this.widget.authClient.tokenManager.setTokens(tokens);
            this.isLoading = false;
            this.isAccessDenied = false;
            if (this.redirectUrl) {
             this.oktaAuth.setOriginalUri(this.redirectUrl);
            } 
            this.oktaAuth.handleLoginRedirect(tokens);
          }
            
          })
          .catch((err) => {
            //get user email if if session exists
          this.widget.authClient.session.get()
          .then(function (session) {
              localStorage.setItem('emailValue', session.login);
              // logged in
          })
          .catch(function (err) {
          // not logged in
          });
            this.isLoading = false;
            if(err && err.errorCode == 'access_denied'){
              this.isAccessDenied = true;
              this.zone.run(() => {
              this.dialog.open(RequestAccessDialogComponent, {
                panelClass: 'requestAccess-dialog-container',
                hasBackdrop: true,
                disableClose: true,
                data: {
                
                email: localStorage.getItem('emailValue')
                },
                minWidth: '50vw',
            
              });
            })
            }
            // handle OAuthError or AuthSdkError
            //(AuthSdkError will be thrown if app is in OAuthCallback state)
          });


      } else {
              this.isLoading = false;
            this.isAccessDenied = false;
            this.widget
              .showSignInToGetTokens({
                el: '#okta-signin-container',
                scopes: CiamConfig.oidc[window.location.origin].scopes,
              })
              .then((tokens: any) => {
                if(environment.aemLoginPage !== ''){
                  window.location.href= environment.aemLoginPage;
                }else{
                  this.widget.remove();
                  const originalUri = this.oktaAuth.getOriginalUri();
                  this.oktaAuth.setOriginalUri('/main');
                  this.oktaAuth.handleLoginRedirect(tokens);
              // window.location.href = environment.aemLoginPage;
                }
              })
              .catch((err: any) => {
                throw err;
              });
              this.redirectIfAlreadyLoggedin();
          }
    });
  }

  
  
  /**
   * @description for unsubscribe all observable variable 
   * @returns Boolean
   */
  unsubscribeValue(): Boolean{
    this.userService.oktaUesrProfile$.next(null);
    this.userService.oktaUesr$.next(null);
    this.loginStatusWidgetService.oktaLoginWidget$.next(null);
    return true;
  }
}
