import { Component, Inject, OnInit } from "@angular/core";
import { MAT_DIALOG_DATA } from "@angular/material/dialog";
import { EmailValidationService } from '../../email-validation.service';

import CiamConfig from '../../app.config';
import { Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { MatDialog } from "@angular/material/dialog";
import { TranslateService } from '@ngx-translate/core';
import { RequestAccessRestrictDialogComponent } from "./request-access-restrict-dialog/request-access-restrict-dialog.component";

declare var $: any;

const clientId = CiamConfig.oidc[window.location.origin].application_context_id;

@Component({
  selector: 'app-request-access-dialog',
  templateUrl: './request-access-dialog.component.html',
  styleUrls: ['./request-access-dialog.component.scss'],
})
export class RequestAccessDialogComponent  {

  unAuthorizedMsg: any;
  unAuthorizedMsg1: any;
  isdisabled: boolean = false;
  loaderText:any;
  loaderText1:any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public oktaAuth: OktaAuthService, private emailValidation: EmailValidationService, public router: Router,public translate: TranslateService) { 
    this.isdisabled = false;
  }

 



  //request button submit

  onSubmit() {

    this.isdisabled = true;
    this.loaderText = this.translate.instant('authorizeUserMsg');
    this.loaderText1 = this.translate.instant('validateUserMsg');
    
    setTimeout(() =>{
      if(document.getElementById("loaderMsg")){
      document.getElementById("loaderMsg").innerHTML = this.loaderText1;
    }}, 3000);

    let emilId = this.data.email == !undefined ? this.data.email : localStorage.getItem('emailValue');
    


    // Call Email Validation service
    this.emailValidation.getEmail(emilId, clientId).subscribe((response: any) => {
      if(response.status == 200){
        const responseData = response.data;

        if (responseData.redirectURL) {
          // navigate to the registration page
          // this.router.navigate(['registration']);
          window.location.href = responseData.redirectURL;
        } else if (responseData.message) {
          // Show modal popup window        
          // this.router.navigate(['login']); 
          // window.sessionStorage.setItem("messageText", responseData.message)
          this.isdisabled = false;
          this.unAuthorizedMsg = responseData.message;  
          this.unAuthorizedMsg1 = {
            message: responseData.message,
            status: 'REGISTERED'
          }
          
          this.dialog.open(RequestAccessRestrictDialogComponent, {
            panelClass: 'requestAccessRestrict-dialog-container',
            id: 'requestAccessRestrict-dialog',
            hasBackdrop: true,
            disableClose: true,
            
            data: {
              message: this.unAuthorizedMsg1
            },
            minWidth: '50vw',
          });
        }
      
      }
      
    }, (error)=> {
      this.isdisabled = false;
    })
    
  }


  close() {
    localStorage.clear();
    this.oktaAuth.signOut();
  }

}

export interface MessageData {
  message: string
}
