import { Component, Inject, OnInit } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from "@angular/material/dialog";
import { Router } from '@angular/router';
import Swal from 'sweetalert2/dist/sweetalert2.all.min.js';
import { OktaAuthService } from '@okta/okta-angular';
import { GlobalMessageDialogComponent } from "src/app/global-message-dialog/global-message-dialog.component";


declare var $: any;

@Component({

selector: 'app-request-access-restrict-dialog',
templateUrl: './request-access-restrict-dialog.component.html',
styleUrls: ['./request-access-restrict-dialog.component.scss'],

})

export class RequestAccessRestrictDialogComponent  {

    unAuthorizedMsg: any;     
    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<RequestAccessRestrictDialogComponent>, public oktaAuth: OktaAuthService, public router: Router, public dialog: MatDialog) {
    
      this.unAuthorizedMsg = this.data.message.message;
if (data.message.message==="Please return to the login page and use the contact information under \"Need help\" for assistance."){
  Swal.fire({
    title: 'Sorry, there is an issue with your account',
    html:data.message.message,
    type: 'success',
    showCancelButton: true,
    showConfirmButton: false,
    showCloseButton: true,
    allowOutsideClick: false,
    cancelButtonText: "OK",
    customClass: {
      container: 'restrict-access-popup',
  }
  }).then((result) => {
    localStorage.clear();
      this.oktaAuth.signOut();
    })
}else{
      Swal.fire({
        title: 'Access not available',
        html:data.message.message,
        type: 'success',
        showCancelButton: true,
        showConfirmButton: false,
        showCloseButton: true,
        allowOutsideClick: false,
        cancelButtonText: "OK",
        customClass: {
          container: 'restrict-access-popup',
      }
      }).then((result) => {
        localStorage.clear();
          this.oktaAuth.signOut();
        })
      
      }
    }
    
    close() {
      localStorage.clear();
      this.oktaAuth.signOut();
    
    }
    
  }
    
    export interface MessageData {
    message: string
    
    }