import { tap, retry } from 'rxjs/operators';
import { BehaviorSubject} from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { UserService } from 'src/lib/service/user.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  }),
};

export interface LoginWidgetResponse {
  LastLogin: string;
  data: LoginWidget;
  message: string;
  passwordexpiry: string;
  status: string;
}
export interface LoginWidget {
  passWordExpiry: string;
  passwordexpiry: string;
  lastLoginStatus: string;
  firstNamePhonetic: string;
  lastNamePhonetic: string;
  userPersona: string;
  firstName: string;
  lastName: string;
  riskLevel: string,
  passWordExpiryDaysLeft: number,
}

@Injectable({
  providedIn: 'root',
})
export class LoginStatusWidgetService {
  public apiUrl = environment.loginWidgetApiUrl;
  public oktaLoginWidget$: BehaviorSubject<LoginWidget> = new BehaviorSubject<LoginWidget>(null);

  constructor(private httpClient: HttpClient,private userService:UserService) {}


  getLoginStatusWidget(guid) {
   return this.httpClient.get<LoginWidgetResponse>(this.apiUrl + guid, httpOptions).pipe(
     retry(3),
     tap(response => {
      if (response.hasOwnProperty("data")) {
         this.oktaLoginWidget$.next(response.data);
       }
    }));
 }
}
